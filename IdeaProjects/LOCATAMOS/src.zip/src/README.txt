🎮 STRANGER THINGS: RESCATA A WILL
📖 Descripción
Juego de aventura basado en texto ambientado en el universo de Stranger Things. El jugador debe tomar decisiones para encontrar y rescatar a Will Byers del Upside Down, explorando Hawkins, resolviendo puzzles y recolectando objetos clave.
🎯 Características

Sistema de escenas interactivas: 14 escenas principales con múltiples opciones
Sistema de inventario: Recolecta y usa objetos importantes
Mini-juego Ahorcado: Resuelve palabras relacionadas con Stranger Things
Mapa interactivo: Visualiza tu ubicación en Hawkins
Múltiples finales: Tus decisiones determinan el resultado (Bueno, Neutro o Malo)
Estadísticas de juego: Tiempo, decisiones tomadas, items recolectados

🛠️ Requisitos del Sistema

Java Development Kit (JDK): Versión 8 o superior
Sistema Operativo: Windows, macOS o Linux
Terminal/Consola: Para ejecutar el juego